﻿//This program is designed to classify an input provided by the user as a character, integer, float, boolean,
//or special symbol, and it keeps running until the user types "exit" to quit.
using System;

namespace CharacterTypeChecker
{
    class Program
    {
        static void Main(string[] args)
        {
            //infinite Loop to keep the program running until the user chooses to exit
            while (true)
            {
                // Prompt the user to enter a value
                Console.Write("Enter a character or value or type 'exit' to quit : ");
                string input = Console.ReadLine();

                //check if the user wants to exit the program
                if (input.ToLower() == "exit")
                {
                    break; // exit the infinite Loop and stop the program
                }
                // Check if the input is a single character
                if (input.Length == 1)
                {
                    char ch = input[0];

                    // Check if the character is a vowel
                    if ("aeiouAEIOU".IndexOf(ch) >= 0)
                    {
                        Console.WriteLine("The character is a vowel.");
                    }
                    // Check if the character is a consonant (letter but not a vowel)
                    else if (char.IsLetter(ch))
                    {
                        Console.WriteLine("The character is a consonant.");
                    }
                    // Check if the character is a digit (integer)
                    else if (char.IsDigit(ch))
                    {
                        Console.WriteLine("The character is an integer.");
                    }
                    else
                    {
                        Console.WriteLine("The character is a special symbol or other.");
                    }
                }
                else
                {
                    // Check if the input is an integer
                    if (int.TryParse(input, out int intResult))
                    {
                        Console.WriteLine("The input is an integer.");
                    }
                    // Check if the input is a float
                    else if (float.TryParse(input, out float floatResult))
                    {
                        Console.WriteLine("The input is a float.");
                    }
                    // Check if the input is a boolean (true/false)
                    else if (bool.TryParse(input, out bool boolResult))
                    {
                        Console.WriteLine("The input is a boolean.");
                    }
                    else
                    {
                        Console.WriteLine("The input type is unrecognized.");
                    }
                }

                // Pause the console before closing
                Console.ReadKey();
            }
        }
    }
}
