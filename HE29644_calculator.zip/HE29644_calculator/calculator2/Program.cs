﻿//advance calculator
using System;

namespace MyCalculator
{                                
    class Program
    {
        static void Main(string[] args)
        {
           // Do-while loop to continuously perform calculations until the user decides to stop

            do
            {
                //declare variables to stote the 2 numbers and the result
                double num1 = 0;
                double num2 = 0;
                double result = 0;

                // Display a message indicating that the calculator program is starting
                Console.WriteLine("Calculator Program");

                // Prompt the user to enter the first number and convert the input to a double
                Console.Write("Please enter number 1: ");
                num1 = Convert.ToDouble(Console.ReadLine());

                // Prompt the user to enter the second number and convert the input to a double
                Console.Write("Please enter number 2: ");
                num2 = Convert.ToDouble(Console.ReadLine());

                // Display a menu of arithmetic operation options for the user to choose from
                Console.WriteLine("Please enter an option: ");
                Console.WriteLine("\t+ : Add");//addition
                Console.WriteLine("\t- : Subtract");//substraction
                Console.WriteLine("\t* : Multiply");//multiplication
                Console.WriteLine("\t/ : Divide");//division
                Console.Write("Please enter an option: ");

                // Perform the operation based on the user's choice using a switch statement
                switch (Console.ReadLine())
                {
                    //case for addition
                    case "+":
                        result = num1 + num2;
                        Console.WriteLine($"Your result: {num1} + {num2} = " + result);
                        break;

                    //case for substraction
                    case "-":
                        result = num1 - num2;
                        Console.WriteLine($"Your result: {num1} - {num2} = " + result);
                        break;

                    //case for multiplication
                    case "*":
                        result = num1 * num2;
                        Console.WriteLine($"Your result: {num1} * {num2} = " + result);
                        break;

                     //case for division
                    case "/":
                        result = num1 / num2;
                        Console.WriteLine($"Your result: {num1} / {num2} = " + result);
                        break;

                    // Default case if the user enters an invalid option
                    default:
                        Console.WriteLine("That was not a valid option.");
                        break;
                }

                // Ask the user if they want to perform another calculation
                Console.Write("Would you like to continue? (Y = yes, N = No): ");
            } while (Console.ReadLine().ToUpper() == "Y");


            // Display a message when the user exits the program
            Console.WriteLine("Bye!");
            // Wait for a key press before closing the console
            Console.ReadKey();
        }
    }
}