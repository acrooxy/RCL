﻿using System;

class MoodChecker
{
    static void Main()
    {
        Console.WriteLine("How are you feeling today?");
        string mood = Console.ReadLine().ToLower();

        if (mood.Contains("happy"))
            Console.WriteLine("That's awesome to hear!");
        else if (mood.Contains("sad"))
            Console.WriteLine("It's okay to feel sad. Be kind to yourself.");
        else
            Console.WriteLine("Interesting mood... stay strong!");
    }
}