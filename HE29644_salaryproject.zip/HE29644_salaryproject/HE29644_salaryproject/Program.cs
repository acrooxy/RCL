﻿using System;
namespace Salary
{
    class Program // Program class to define the main functionality
    {
        static void Main(string[] args) //main method: entry point for the program
        {
            // Displaying a welcome message to the user
            Console.WriteLine("Welcome to the department application");

            // Declaring two string variables: 'Name' for the user's name and 'staff' for the department
            string Name, staff;

            // Declaring three double variables: 'Salary', 'deduction', and 'netsalary' to store financial information
            double Salary, deduction, netsalary;

            // Prompting the user to enter their name
            Console.WriteLine("Please enter your name: ");
            Name = Console.ReadLine();

            // Prompting the user to enter their department name
            Console.WriteLine("What is your department: ");
            staff = Console.ReadLine();

            // Prompting the user to enter their salary
            Console.WriteLine("What is your salary: ");
            Salary = Convert.ToInt32(Console.ReadLine());

            // Calculating the deduction as 30% of the salary
            deduction = Salary * 0.3;

            // Calculating the net salary by subtracting the deduction from the salary
            netsalary = Salary - deduction;

            // Displaying the user's net salary, name, and department
            Console.WriteLine("Your salary after deduction is = " + netsalary + "\n" + " " + Name + " " + "department name is " + " " + staff);

            // Waiting for the user to press a key before closing the console window
            Console.ReadLine();

        }
    }
}

