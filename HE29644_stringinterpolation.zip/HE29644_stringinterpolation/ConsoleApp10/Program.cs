﻿//This C# program defines a simple class Vegetable to represent a vegetable with a name and uses an enumeration Unit to define various units of measurement. 
using System;
namespace MyApplication
{
    // Class to represent a vegetable with a name
    public class Vegetable
    {
        //Constructor that takes a vegetable name and assigns it to the Name property
        public Vegetable(string name) => Name = name;
        // Read-only property to store the name of the vegetable
        public string Name { get; }
        // Override the ToString method to return the vegetable's name when the object is used in a string context
        public override string ToString() => Name;
    }
    // The main program class containing the entry point for the application
    public class Program
        {
        // Enum representing units of measurement (e.g., item, kilogram, gram, dozen)
        public enum Unit { item, kilogram, gram, dozen};
        // Main method: Entry point of the program
        public static void Main()
            {
            // Create an instance of the Vegetable class, representing an "eggplant"
            var item = new Vegetable("eggplant");

            //Get the current date and time, and store it in the 'date' variable
            var date = DateTime.Now;

            // Declare a price of the vegetable in decimal format (1.99)
            var price = 1.99m;
            // Assign a unit of measurement to the vegetable (item in this case)
            var unit = Unit.item;
            // Print the details to the console using string interpolation
            // {date:d} formats the date in a short date format, {price:C2} formats the price as currency with 2 decimal places
            Console.WriteLine($"On {date:d}, the price of {item} was {price:C2} per {unit}");
            }
        }
        
    
}

