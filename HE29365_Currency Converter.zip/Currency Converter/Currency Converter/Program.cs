﻿using System;

class CurrencyConverter
{
    static void Main()
    {
        Console.WriteLine("Welcome to the Currency Converter!");

        // Exchange rates to USD
        double euroRate = 0.85;
        double poundRate = 0.75;
        double yenRate = 110.5;

        Console.Write("Enter amount in USD: ");
        double usd = double.Parse(Console.ReadLine());

        Console.WriteLine("\nSelect target currency:");
        Console.WriteLine("1. Euro");
        Console.WriteLine("2. British Pound");
        Console.WriteLine("3. Japanese Yen");
        int choice = int.Parse(Console.ReadLine());

        double convertedAmount = 0;

        switch (choice)
        {
            case 1:
                convertedAmount = usd * euroRate;
                Console.WriteLine($"{usd} USD is {convertedAmount:F2} Euro.");
                break;
            case 2:
                convertedAmount = usd * poundRate;
                Console.WriteLine($"{usd} USD is {convertedAmount:F2} British Pounds.");
                break;
            case 3:
                convertedAmount = usd * yenRate;
                Console.WriteLine($"{usd} USD is {convertedAmount:F2} Japanese Yen.");
                break;
            default:
                Console.WriteLine("Invalid choice!");
                break;
        }
    }
}

