﻿//this program is designed to take a student name and grade as input and 
//display their corresponding grade letter based on their score
using System;
namespace expression
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to my new application design student calculations grades");
            // declaring two variables as one string and integer datatype
            string name;//declaring variable as string datatype
            int score; // declaring variable as integer datatype
            Console.WriteLine("Please enter student name ");
            name = Console.ReadLine();
            Console.WriteLine("Please enter student grade ");
            score = Convert.ToInt32(Console.ReadLine());

            if(score>=90)
            {
                Console.WriteLine(name + " Congratulations your grade is A");
            }
            else if(score>=80)
            {
                Console.WriteLine(name + " Congratulations your grade is B");
            }
            else if(score>=70)
            {
                Console.WriteLine(name + " Congratulations your grade is C");

            }
            else if (score>=60)
            {
                Console.WriteLine(name + " Congratulations your grade is D");

            }
            else 
            {
                Console.WriteLine(name + " you failed your grade is F");
            }
        }
    }
}
