﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("=== Biology Assistant Menu ===");
        Console.WriteLine("1. Count amino acids in a sequence");
        Console.WriteLine("2. Show mutation");
        Console.WriteLine("3. Exit");
        Console.WriteLine("Please enter your option (1-3):");

        string choice = Console.ReadLine();



        switch (choice)
        {
            case "1":
                Console.Write("Enter sequence: ");
                string seq = Console.ReadLine();
                Console.WriteLine($"Length: {seq.Length} amino acids.");
                break;

            case "2":
                Console.Write("Original: ");
                string orig = Console.ReadLine();
                Console.Write("Mutant: ");
                string mut = Console.ReadLine();
                Console.WriteLine($"You entered mutation: {orig} to {mut}");
                break;

            case "3":
                Console.WriteLine("Exiting program.");
                break;

            default:
                Console.WriteLine("Invalid option.");
                break;
        }
    }
}
