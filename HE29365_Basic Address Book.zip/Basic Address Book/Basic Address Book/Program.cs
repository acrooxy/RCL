﻿using System;
using System.Collections;

class Contact
{
    public string Name;
    public string Phone;
    public string Email;

    public Contact(string name, string phone, string email)
    {
        Name = name;
        Phone = phone;
        Email = email;
    }

    public void Display()
    {
        Console.WriteLine($"Name: {Name}, Phone: {Phone}, Email: {Email}");
    }
}

class Program
{
    static void Main()
    {
        ArrayList contacts = new ArrayList();
        string choice;

        do
        {
            Console.WriteLine("\n=== Address Book ===");
            Console.WriteLine("1. Add Contact");
            Console.WriteLine("2. View Contacts");
            Console.WriteLine("3. Exit");
            Console.Write("Choose an option (1-3): ");
            choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    Console.Write("Enter name: ");
                    string name = Console.ReadLine();

                    Console.Write("Enter phone number: ");
                    string phone = Console.ReadLine();

                    Console.Write("Enter email: ");
                    string email = Console.ReadLine();

                    contacts.Add(new Contact(name, phone, email));
                    Console.WriteLine("Contact added!");
                    break;

                case "2":
                    Console.WriteLine("\n--- Contact List ---");
                    if (contacts.Count == 0)
                    {
                        Console.WriteLine("No contacts to display.");
                    }
                    else
                    {
                        foreach (object obj in contacts)
                        {
                            Contact c = (Contact)obj;
                            c.Display();
                        }
                    }
                    break;

                case "3":
                    Console.WriteLine("Exiting...");
                    break;

                default:
                    Console.WriteLine("Invalid option.");
                    break;
            }

        } while (choice != "3");
    }
}

