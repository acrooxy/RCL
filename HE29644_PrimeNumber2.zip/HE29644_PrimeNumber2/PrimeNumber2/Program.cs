﻿//This C# program is designed to check whether a given number is prime or not
using System;

namespace LogicalPrograms
{
    public class Program
    {
        static void Main(string[] args)
        {
            // Infinite loop to keep the program running until the user chooses to exit
            while (true)
            {
                // Prompt the user to enter a number
                Console.Write("Enter a Number (or type 'exit' to quit): ");
                string input = Console.ReadLine();

                // Check if the user wants to exit the program
                if (input.ToLower() == "exit")
                {
                    break;  // Exit the infinite loop and stop the program
                }

                // Try to parse the input as an integer, and check for valid input
                if (int.TryParse(input, out int number))
                {
                    // Assume the number is prime unless proven otherwise
                    bool IsPrime = true;

                    // Check divisibility starting from 2 up to number/2
                    for (int i = 2; i <= number / 2; i++)
                    {
                        if (number % i == 0)
                        {
                            IsPrime = false;  // Mark as non-prime if divisible
                            break;            // Exit the loop since it's not prime
                        }
                    }

                    // Output the result based on whether the number is prime or not
                    if (IsPrime && number > 1)  // A prime number must be greater than 1
                    {
                        Console.WriteLine($"{number} is Prime.");
                    }
                    else
                    {
                        Console.WriteLine($"{number} is not Prime.");
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter a valid number or type 'exit' to quit.");
                }

                // Add a line break for better readability before the next iteration
                Console.WriteLine();
            }
        }
    }
}