﻿//This C# program evaluates the grades of students based on their marks and assigns them
//corresponding grades.
//two arrays, one for storing the students' names and another for their corresponding marks
using System;
class Program
{
    // Main method: Entry point of the program
    static void Main(string[] args)
    {
        // Print the purpose of the program
        Console.WriteLine("An array finding each student grades ");

        // Array to store student names
        string[] studentname = { "Sam ", "Maria ", "Miha ", "Ana ", "David ", "Vicky " };

        // Array to store corresponding marks of each student
        int[] marks = { 77, 88, 99, 92, 79, 69 };

        // Loop through the array of students and evaluate their grades
        for (int i = 0; i < studentname.Length; i++)
        {

            // If the student's mark is greater than or equal to 90, assign Grade A
            if (marks[i] >= 90)
            {
                Console.WriteLine(studentname[i] + " Grade:" + " A Excelent");
            }

            // If the student's mark is between 80 and 89, assign Grade B
            else if (marks[i] >= 80 && marks[i] < 90)
            {
                Console.WriteLine(studentname[i] + " Grade:" + " B Very Good");
            }

            // If the student's mark is between 70 and 79, assign Grade C
            else if (marks[i] >= 70 && marks[i] < 80)
            {
                Console.WriteLine(studentname[i] + " Grade:" + " C Average");
            }

            // If the student's mark is between 60 and 69, assign Grade D
            else if (marks[i] >= 60 && marks[i] < 70)
                {
                Console.WriteLine(studentname[i] + " Grade:" + " D Just Passed");
            }
        }
    }
}